//Archivo de c�digo del M�dulo Configuraci�n

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "MenuP.h"
#include "IntDatos.h"
#include "Complementos.h"
#include "Configuracion.h"
#define MAX 100

void Borrar(){
    static char ctrl,ctrl1;
    static int ctrl2;
    FILE *in;
    do{
        ctrl=0;
        ctrl2=0;
        printf("\n================================\nIntroduzca cual de los ficheros desea eliminar.\n [1] Juego.txt | [2] Barcos.txt | [3] Ambos | [0] Salir\n");
        do{
            scanf("%i",&ctrl2);
            fflush(stdin);
            if(ctrl2!=0 && ctrl2!=1 && ctrl2!=2 && ctrl2!=3 && ctrl2!=4) printf("\nEl numero introducido no es v�lido, por favor, introduzca un numero del 1 al 4.\n");
        }while(ctrl2!=0 && ctrl2!=1 && ctrl2!=2 && ctrl2!=3 && ctrl2!=4);
        switch(ctrl2){
        case 0:
            return;
        case 1:
            printf("\nUsted va a eliminar el fichero Juego.txt. �Esta seguro? (Esta operacion no se podra deshacer) [S] [N]\n");
            confirmacion(&ctrl);
            if(ctrl=='S'||ctrl=='s'){
                if((in=fopen("./Juego.txt","w"))!=NULL){
                   fclose(in);
                   printf("\nEliminacion completada\n");
                }
                else
                    printf("\nError al borrar el fichero\n");
            }
            else
                printf("\nEliminacion cancelada\n");
            break;
        case 2:
            printf("\nUsted va a eliminar el fichero Barcos.txt. �Esta seguro? (Esta operacion no se podra deshacer) [S] [N]\n");
            confirmacion(&ctrl);
            if(ctrl=='S'||ctrl=='s'){
                if((in=fopen("./Barcos.txt","w"))!=NULL){
                   fclose(in);
                   printf("\nEliminacion completada\n");
                }
                else
                    printf("\nError al borrar el fichero\n");
            }
            else
                printf("\nEliminacion cancelada\n");
            break;
        case 3:
            printf("\nUsted va a eliminar ambos ficheros. �Esta seguro? (Esta operacion no se podra deshacer) [S] [N]\n");
            confirmacion(&ctrl);
            if(ctrl=='S'||ctrl=='s'){
                if((in=fopen("./Juego.txt","w"))!=NULL){
                   fclose(in);
                }
                else
                    printf("\nError al borrar Juego.txt\n");
                if((in=fopen("./Barcos.txt","w"))!=NULL){
                   fclose(in);
                }
                else
                    printf("\nError al borrar Barcos.txt\n");
                printf("\nEliminacion completada\n");
            }
            else
                printf("\nEliminacion cancelada\n");
            break;
        }
        printf("\n================================\n�Desea eliminar otro fichero? [S] [N]\n");
        confirmacion(&ctrl1);
    }while(ctrl1!='N' && ctrl1!='n');
}

void mostrar_barcos(barcos v_barcos[],int n_barcos){
    static int i;
    printf("\n================================\nEL ASTILLERO\n================================\n");
    printf("ID---Nombre---Cantidad\n\n");
    for(i=0;i<n_barcos;i++){
            printf("%i-",v_barcos[i].id_barco);
            printf("%s: ",v_barcos[i].nomb_barco);
            if(v_barcos[i].num_bar_tipo==NULL)
                v_barcos[i].num_bar_tipo=0;
            printf("%i\n",v_barcos[i].num_bar_tipo);
    }
}

void mostrar_config(jugadores jug_vect[],juego jueg){
    static int i;
    printf("\n================================\nConfiguracion actual\n================================\n");
    for(i=0;i<2;i++){
        printf("\nDatos del jugador %i:\n",i+1);
        printf("Id: %i\n",jug_vect[i].id_jug);
        printf("Nombre: %s\n",jug_vect[i].nomb_jug);
        if(jug_vect[i].tipo_disp==0)
            printf("Tipo de disparo: Manual\n");
        else{
            if(jug_vect[i].tipo_disp==1)
            printf("Tipo de disparo: Automatico\n");
        }
        if(jug_vect[i].comienza==0) //Directiva temporal hasta que se a�ada en el registro
            printf("Comienza: Este jugador no desea comenzar primero\n");
        else{
            if(jug_vect[i].comienza==1) //Directiva temporal hasta que se a�ada en el registro
            printf("Comienza: Este jugador desea comenzar primero\n");
        }
        printf("\n================================\n");
    }
    printf("\nDimensiones del tablero: %i x %i\n",jueg.tam_tablero,jueg.tam_tablero);
    printf("\n================================\n");
}

void carga_confi(juego *jueg, bar_vect *v_bar, jug_vect *jugador){
    FILE *in;
    static char buffer[MAX];
    static int i;
    if((in=fopen("./Juego.txt","r"))!=NULL){
        fgets(buffer,MAX,in);
        sscanf(buffer,"%i-%i-%i",&jueg->tam_tablero,&jueg->num_total_bar,&v_bar->num_tipo_bar);
        v_bar->bar=(barcos*)malloc((v_bar->num_tipo_bar)*sizeof(barcos));
        for(i=0;i<(v_bar->num_tipo_bar);i++){
              fgets(buffer,MAX,in);
              sscanf(buffer," %c-%i",&v_bar->bar[i].id_barco,&v_bar->bar[i].num_bar_tipo);
        }
        fgets(buffer,MAX,in);
        sscanf(buffer,"%i-%[^-]-%i-%c-%i",&jugador->jug[0].id_jug, jugador->jug[0].nomb_jug, &jugador->jug[0].num_disp, &jugador->jug[0].tipo_disp, &jugador->jug[0].ganador);
        //este bucle for existe para saltarse los tableros
        for(i=1;i<=((jueg->tam_tablero)*2);i++){
            fgets(buffer,MAX,in);
        }
        fgets(buffer,MAX,in);
        sscanf(buffer,"%i-%[^-]-%i-%c-%i",&jugador->jug[1].id_jug, &jugador->jug[1].nomb_jug, &jugador->jug[1].num_disp, &jugador->jug[1].tipo_disp, &jugador->jug[1].ganador);
    }
    else
        printf("\nError de apertura del fichero Juego.txt\n");
    fclose(in);
}

void carga_barco(bar_vect *v_bar){
    FILE *in;
    static char buffer[MAX];
    static int i;
    if((in=fopen("./Barcos.txt","r"))!=NULL){
        for(i=0;i<(v_bar->num_tipo_bar);i++){
            fgets(buffer,MAX,in);
            sscanf(buffer,"%[^-]-%c-%i",&v_bar->bar[i].nomb_barco,&v_bar->bar[i].id_barco, &v_bar->bar[i].tam_barco);
        }
    }
    else
        printf("\nError de apertura del fichero Barcos.txt\n");
    fclose(in);
}

void barc_fich(bar_vect *v_bar){
    FILE *in;
    static int i;
    if((in=fopen("./Barcos.txt","w"))!=NULL){
        for(i=0;i<(&v_bar->num_tipo_bar);i++){
            fprintf(in,"%s-%c-%i\n",&v_bar->bar[i].nomb_barco,&v_bar->bar[i].id_barco, &v_bar->bar[i].tam_barco);
        }
    }
    else
        printf("\nError de apertura del fichero Barcos.txt\n");
    fclose(in);
}

void confi_fich(juego *jueg,bar_vect *v_bar,jug_vect *jugador){
    FILE *in;
    static int i, j, k, l;
    if((in=fopen("./Juego.txt","w"))!=NULL){
        fprintf(in,"%i-%i-%i\n",jueg->tam_tablero,jueg->num_total_bar,v_bar->num_tipo_bar);
        for(i=0;i<(&v_bar->num_tipo_bar);i++){
            fprintf(in,"%c-%i\n",v_bar->bar[i].id_barco,v_bar->bar[i].num_bar_tipo);
        }
        for(l=0;l<2;l++){
            fprintf(in,"%i-%s-%i-%c-%i",jugador->jug[l].id_jug, jugador->jug[l].nomb_jug, jugador->jug[l].num_disp, jugador->jug[l].tipo_disp, jugador->jug[l].ganador);
            for(k=0;k<2;k++){
                for(i=0;i<(&jueg->tam_tablero);i++){
                    for(j=0;j<(&jueg->tam_tablero);j++){
                        fprintf(in,"- ");
                    }
                    fprintf(in,"\n");
                }
            }
        }
    }
    else
        printf("\nError de apertura del fichero Barcos.txt\n");
    fclose(in);
}

