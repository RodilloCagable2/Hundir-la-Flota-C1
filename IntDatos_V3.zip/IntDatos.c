//Archivo de c�digo del M�dulo Introducir Datos

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "IntDatos.h"
#include "Complementos.h"

void int_nombre(char nombre[]){
    static char ctrl;
    do{
        fflush(stdin);
        printf("\n================================\nIntroduzca su nombre por favor:\n");
        fgets(nombre,20,stdin);
        terminador_cad(nombre);
        //Mostrar el nombre escrito por si no es del agrado del usuario
        printf("\n================================\nEl nombre introducido es:\n");
        printf("%s",nombre);
        //Easter eggs
        if(strcmp(nombre,"Among Us\0")==0) printf("\nYou're so sussy\n");
        if(strcmp(nombre,"Harry Potter\0")==0) printf("\nYou're a wizard Harry\n");
        //Opcion para sobreescribir el nombre en caso de necesitarlo
        printf("\n================================\n�Desea cambiar el nombre? [S] [N]\n");
        ctrl=confirmacion;
    }while(ctrl!='N' && ctrl!='n');
}

void comienza(int *valor){
    static char ctrl;
    do{
        do{
        printf("\n================================\nIntroduzca si desea comenzar el primero de la partida: [S]=1 [N]=0\n");
        scanf("%i",*valor);
        fflush(stdin);
        if(*valor!=0 && *valor!=1) printf("\nDebe introducir un 0 o un 1\n");
        }while(*valor!=0 && *valor!=1);
        if(valor==0) printf("\nUsted ha establecido no comenzar primero\n");
        if(valor==1) printf("\nUsted ha establecido comenzar primero\n");
        printf("\n================================\n�Desea cambiar este ajuste? [S] [N]\n");
        ctrl=confirmacion;
    }while(ctrl!='N' && ctrl!='n');
}

void tipo_disparo(int *valor){
    static char ctrl;
    do{
        do{
        printf("\n================================\nIntroduzca si desea comenzar el primero de la partida: [Automatico]=A [Manual]=M\n");
        scanf("%c",*valor);
        fflush(stdin);
        if(*valor!='A' && *valor!='a' && *valor!='M' && *valor!='m') printf("\nDebe introducir un caracter valido\n");
        }while(*valor!=0 && *valor!=1);
        if(valor=='M' || valor=='m') printf("\nUsted ha establecido disparo manual\n");
        if(valor=='A' || valor='a') printf("\nUsted ha establecido disparo automatico\n");
        printf("\n================================\n�Desea cambiar este ajuste? [S] [N]\n");
        ctrl=confirmacion;
    }while(ctrl!='N' && ctrl!='n');
}

void tam_tab(barcos v_barcos[],int n_barcos, int *valor){
    static char ctrl1;
    static int i,max,ctrl2;
    max=0;
    for(i=0;i<n_barcos;i++){
        max=max+((9+((v_barcos[i].tam_barco)-1)*3)*v_barcos[i]*v_barcos[i].num_bar_tipo);
    }
    do{
        printf("\n================================\nIntroduzca el numero que determinara las dimensiones del tablero\n");
        do{
        ctrl2=1;
        scanf("%i",*valor);
        fflush(stdin);
        if(((*valor)*(*valor))<max){
            printf("\nLas dimensiones del tablero no son lo suficientemente grandes, por favor, escoja un numero mayor que %i\n",max);
            ctrl2=0;
        }}while(ctrl2==0);
        printf("\n================================\nLas dimensiones de su tablero seran de %i x %i\n�Desea cambiarlas? [S] [N]\n");
        ctrl1=confirmacion;
    }while(ctrl1!='N' && ctrl1!='n');
}

void cantipbar(barcos v_barcos[],int n_barcos){
    static char ctrl1,ctrl2;
    static int i, pos;
    printf("\n================================\nEL ASTILLERO\n================================\n");
    for(i=0;i<n_barcos;i++){
            printf("%i-",v_barco[i].id_barco);
            printf("%s: ",v_barcos[i].nomb_barco);
            if(v_barcos[i].num_bar_tipo==NULL)
                v_barcos[i].num_bar_tipo=0;
            printf("%i\n",v_barcos[i].num_bar_tipo);
    }
    do{
            do{
            printf("\n================================\nSeleccione la id del barco cuya cantidad desea modificar\n");
            do{
            scanf("%i",&pos);
            fflush(stdin);
            i=0;
            while(pos!=v_barco[i].id_barco&&i<n_barcos)
                i++;
            if(i==n_barcos)
            printf("La id indicada no esta definida, inserte otro valor\n")
            }while(i==n_barcos);
            printf("\nIntroduzca la nueva cantidad de %s\n",v_barco[i].nomb_barco);
            scanf("%i",&v_barco[i].num_bar_tipo);
            fflush(stdin);
            printf("\n================================\n�Desea cambiar otra cantidad de otro barco? [S] [N]");
            ctrl1=confirmacion;
            }while(ctrl1!='N' && ctrl1!='n');
        printf("\n================================\nEL ASTILLERO\n================================\n");
        for(i=0;i<n_barcos;i++){
        printf("%i-",v_barco[i].id_barco);
        printf("%s: ",v_barcos[i].nomb_barco);
        if(v_barcos[i].num_bar_tipo==NULL)
            v_barcos[i].num_bar_tipo=0;
        printf("%i\n",v_barcos[i].num_bar_tipo);
        }
        printf("\n================================\nEste es su astillero actual. �Desea hacer algun otro cambio a la cantidad de los barcos? [S] [N]\n");
        ctrl2=confirmacion;
    }while(ctrl2!='N' && ctrl2!='n');
}
