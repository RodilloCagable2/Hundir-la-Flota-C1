//Archivo de cabecera del M�dulo Configuraci�n

#ifndef CONFIGURACION_H_INCLUDED
#define CONFIGRACION_H_INCLUDED

//Funciones para el manejo de ficheros

//Funci�n Borrar Ficheros
//Precondici�n: N/A
//Postcondici�n: Dar a elegir al usuario cual de los ficheros eliminar y eliminarlos en el acto
void Borrar();

//Funci�n Mostrar Barcos + La Cantidad de cada uno
//Precondici�n: barcos v_barcos[] es un vector que almacena datos con estructura barcos e int n_barcos el numero total de tipos de barcos.
//Postcondici�n: Mostrar por pantalla todos los tipos de barco y la cantidad de cada uno.
void mostrar_barcos(barcos v_barcos[],int n_barcos);

//Funci�n Mostrar Configuracion
/*Precondici�n: jugadores jug_vect es un vector que almacena datos con esctructura jugadores y  juego jueg es una variable que nos pasar�
                por valor lo almacenado en el registro para su impresi�n*/
//Postcondici�n: Mostrar por pantall la configuraci�n establecida para el juego.
void mostrar_config(jugadores jug_vect[],juego jueg);

//Funci�n: Cargar de fichero Juego.txt a Registro
/*Precondici�n: juego *jueg es un puntero que pasa la totalidad de la estructura juego, bar_vect *v_bar es un puntero que pasa la totalidad de la estructura bar_vect
                jug_vect *jugador es un puntero que pasa la totalidad de la estructura jugador*/
//Postcondici�n: Mover todos los datos relevantes guardados en el fichero y copiarlos en el registro
void carga_confi(juego *jueg,bar_vect *v_bar,jug_vect *jugador);

//Funci�n: Carga de fichero Barcos.txt a Registro
//Precondici�n: bar_vect *v_bar es un puntero que pasa la totalidad de la estructura bar_vect, �El vector barcos *bar ya debe estar creado, esta funci�n no cuenta con direccionamiento din�mico!
//Postcondici�n: Mover todos los datos relevantes guardados en el fichero y copiarlos en el registro
void carga_barco(bar_vect *v_bar);

//Funci�n: Escribir el fichero Barcos.txt
//Precondici�n: bar_vect *v_bar es un puntero que pasa la totalidad de la estructura bar_vect, �El vector barcos *bar ya debe estar creado, esta funci�n no cuenta con direccionamiento din�mico!
//Postcondici�n: Escribir el contenido necesario almacenado en el registro en el fichero, borrando el antiguo de haberlo
void barc_fich(bar_vect *v_bar);

//Funci�n: Escribir el fichero Juego.txt
//Precondici�n:
//Postcondici�n: Escribir el contenido necesario almacenado en el registro en el fichero, borrando el antiguo de haberlo
void confi_fich(juego *jueg,bar_vect *v_bar,jug_vect *jugador);
#endif // CONFIGURACION_H_INCLUDED
